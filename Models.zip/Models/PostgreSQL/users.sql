-- Models/PostgreSQL/users.sql (UPGRADED)

CREATE TABLE users (
    id SERIAL PRIMARY KEY,

    -- Auth
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'reader',

    -- Profile
    username VARCHAR(255),
    profile_photo TEXT,

    -- Stats
    novels_read INTEGER DEFAULT 0,
    chapters_read INTEGER DEFAULT 0,

    -- Bookmarks (array of novel IDs)
    bookmarks INTEGER[] DEFAULT '{}',

    -- Reading history (array of chapter IDs)
    history INTEGER[] DEFAULT '{}',

    -- Notifications (JSON array)
    notifications JSONB DEFAULT '[]',

    -- Preferences (theme, font, etc)
    preferences JSONB DEFAULT '{
        "theme": "light",
        "fontSize": 16,
        "readerMode": "scroll"
    }',

    -- Sessions (device login tracking)
    sessions JSONB DEFAULT '[]',

    -- Leveling system
    xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,

    -- Daily check-in
    last_checkin DATE,
    checkin_streak INTEGER DEFAULT 0,

    -- Activity log
    activity JSONB DEFAULT '[]',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
