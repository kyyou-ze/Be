-- Models/PostgreSQL/favorites.sql
CREATE TABLE favorites (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    novel_id VARCHAR(24) NOT NULL, -- MongoDB ObjectId
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, novel_id)
);
