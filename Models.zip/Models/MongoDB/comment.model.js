// Models/MongoDB/comment.model.js
const mongoose = require('mongoose');

const CommentSchema = new mongoose.Schema({
  content: { type: String, required: true },
  user: { type: Number, required: true }, // PostgreSQL user_id
  chapter: { type: String, required: true }, // chapterId (string/ObjectId)
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Comment', CommentSchema);
