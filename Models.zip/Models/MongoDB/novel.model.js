// Models/MongoDB/novel.model.js
const mongoose = require('mongoose');

const ChapterSchema = new mongoose.Schema({
  title: { type: String, required: true },
  views: { type: Number, default: 0 },
  contentPath: { type: String, required: true }, // path file internal, ex: "/uploads/chapters/novel1/ch1.pdf"
  order: { type: Number, default: 0 },
  updatedAt: { type: Date, default: Date.now }
}, { _id: true });

const NovelSchema = new mongoose.Schema({
  title: { type: String, required: true },
  img: { type: String }, // cover path internal
  year: { type: String },
  summary: { type: String },
  status: { type: String, enum: ['Ongoing', 'Completed'], default: 'Ongoing' },
  type: { type: String },
  genre1: { type: String },
  genre2: { type: String },
  rating: { type: String },
  // Ubah author ke String agar cocok dengan JWT payload yang biasanya berisi string id
  // Jika kamu menyimpan user sebagai ObjectId, gunakan: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
  author: { type: String, required: true },
  genres: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Genre' }],
  chapters: [ChapterSchema],
  updatedAt: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Novel', NovelSchema);
