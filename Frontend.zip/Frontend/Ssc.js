// Sumber data (raw GitHub) - gunakan satu konstanta
const RAW_DATA_URL = 'https://raw.githubusercontent.com/kyyou-ze/Data/main/Data.json';

// Toggle sidebar
function toggleMenu() { document.getElementById("sidebar").classList.toggle("show"); }

// Variabel global untuk menyimpan data novel
let novelData = [];

// Carousel / track dan state akan diambil setelah DOM siap
let track = null;
let slides = [];
let index = 0;
let startX = 0;
let currentTranslate = 0;
let prevTranslate = 0;
let dragging = false;
let autoSlideInterval = null;

// Muat data novel sekali saat diperlukan
async function loadNovelData() {
  try {
    const res = await fetch(RAW_DATA_URL);
    if (!res.ok) throw new Error('Gagal ambil data');
    const data = await res.json();
    novelData = Array.isArray(data) ? data : [];
    return novelData;
  } catch (err) {
    console.error('loadNovelData error:', err);
    novelData = [];
    return novelData;
  }
}

// Setup search realtime, dipanggil setelah elemen ada
function setupRealtimeSearch(searchInput, resultsContainer) {
  if (!searchInput || !resultsContainer) return;

  searchInput.addEventListener('input', () => {
    const keyword = (searchInput.value || '').trim().toLowerCase();
    resultsContainer.innerHTML = '';

    if (keyword === '') {
      resultsContainer.textContent = "Tidak ada hasil";
      return;
    }

    const filtered = novelData.filter(novel =>
      (novel.title || '').toLowerCase().includes(keyword)
    );

    if (filtered.length === 0) {
      resultsContainer.textContent = "Tidak ada hasil";
      return;
    }

    filtered.forEach(novel => {
      const div = document.createElement('div');
      div.classList.add('novel-card');

      const totalViews = Array.isArray(novel.chapters)
        ? novel.chapters.reduce((sum, ch) => sum + (Number(ch.views) || 0), 0)
        : 0;

      div.innerHTML = `
      <div onclick="location.href='desk.html?id=${novel.id}'">
        <img src="${novel.img || ''}" alt="${novel.title || ''}" class="cover-img" />
        <h3>${novel.title || '-'}</h3>
        <p><strong>Status:</strong> ${novel.status || '-'}</p>
        <p><strong>Tahun:</strong> ${novel.year || '-'}</p>
        <p><strong>Genre:</strong> ${[novel.genre1, novel.genre2, novel.genre3].filter(Boolean).join(', ') || '-'}</p>
        <p><strong>Rating:</strong> ${novel.rating || '-'}</p>
        <p><strong>Total Views:</strong> ${totalViews}</p>
        </div>
      `;
      resultsContainer.appendChild(div);
    });
  });
}

// Fungsi search manual (opsional)
async function searchNovel(searchInput, resultsContainer) {
  if (!resultsContainer || !searchInput) return;
  const query = (searchInput.value || '').trim().toLowerCase();
  resultsContainer.innerHTML = '';

  if (!query) {
    resultsContainer.innerHTML = '<p>Silakan ketik judul novel untuk mencari.</p>';
    return;
  }

  try {
    if (!Array.isArray(novelData) || novelData.length === 0) {
      await loadNovelData();
    }

    const filtered = novelData.filter(novel =>
      (novel.title || '').toLowerCase().includes(query)
    );

    if (filtered.length === 0) {
      resultsContainer.innerHTML = '<p>Tidak ditemukan.</p>';
      return;
    }

    filtered.forEach(novel => {
      const item = document.createElement('div');
      item.className = 'novel-card';
      const totalViews = Array.isArray(novel.chapters)
        ? novel.chapters.reduce((sum, ch) => sum + (Number(ch.views) || 0), 0)
        : 0;

      item.innerHTML = `
      <div onclick="location.href='desk.html?id=${novel.id}'">
        <img src="${novel.img || ''}" alt="${novel.title || ''}" class="cover-img" />
        <h3>${novel.title || '-'}</h3>
        <p><strong>Status:</strong> ${novel.status || '-'}</p>
        <p><strong>Tahun:</strong> ${novel.year || '-'}</p>
        <p><strong>Genre:</strong> ${[novel.genre1, novel.genre2, novel.genre3].filter(Boolean).join(', ') || '-'}</p>
        <p><strong>Rating:</strong> ${novel.rating || '-'}</p>
        <p><strong>Total Views:</strong> ${totalViews}</p>
        </div>
      `;
      resultsContainer.appendChild(item);
    });

  } catch (error) {
    console.error('searchNovel error:', error);
    resultsContainer.innerHTML = '<p>Terjadi kesalahan saat mengambil data.</p>';
  }
}

// Load genre ke dropdown
async function loadGenres(dropdown) {
  if (!dropdown) return;
  dropdown.innerHTML = '<p class="genre-loading" style="padding:8px;">Memuat genre...</p>';

  try {
    if (!Array.isArray(novelData) || novelData.length === 0) {
      await loadNovelData();
    }

    if (!Array.isArray(novelData) || novelData.length === 0) {
      dropdown.innerHTML = '<p class="genre-empty" style="padding:8px;">Tidak ada genre.</p>';
      return;
    }

    const genres = new Set();
    novelData.forEach(n => {
      if (n.genre1) genres.add(n.genre1);
      if (n.genre2) genres.add(n.genre2);
      if (n.genre3) genres.add(n.genre3);
    });

    dropdown.innerHTML = '';
    Array.from(genres).sort().forEach(g => {
      const link = document.createElement('a');
      link.href = 'javascript:void(0)';
      link.className = 'genre-item';
      link.setAttribute('data-genre', g);
      link.textContent = g;
      link.addEventListener('click', () => {
        setActiveGenre(g);
        loadGenre(g);
      });
      dropdown.appendChild(link);
    });

  } catch (err) {
    console.error('loadGenres error:', err);
    dropdown.innerHTML = '<p class="genre-error" style="padding:8px;">Gagal memuat genre.</p>';
  }
}

function setActiveGenre(name) {
  document.querySelectorAll('.genre-item').forEach(el => {
    el.classList.toggle('active', el.getAttribute('data-genre') === name);
  });
}

// Tampilkan novel berdasarkan genre
async function loadGenre(genre) {
  const resultsContainer = document.getElementById('searchResults');
  if (!resultsContainer) return;
  resultsContainer.innerHTML = `<p>Memuat novel genre "${genre}"...</p>`;

  try {
    if (!Array.isArray(novelData) || novelData.length === 0) {
      await loadNovelData();
    }

    const filtered = novelData.filter(n =>
      (n.genre1 === genre) || (n.genre2 === genre) || (n.genre3 === genre)
    );

    if (filtered.length === 0) {
      resultsContainer.innerHTML = `<p>Tidak ada novel dengan genre "${genre}".</p>`;
      return;
    }

    resultsContainer.innerHTML = '';
    filtered.forEach(novel => {
      const item = document.createElement('div');
      item.className = 'novel-card';
      const totalViews = Array.isArray(novel.chapters)
        ? novel.chapters.reduce((sum, ch) => sum + (Number(ch.views) || 0), 0)
        : 0;

      item.innerHTML = `
      <div onclick="location.href='desk.html?id=${novel.id}'">
        <img src="${novel.img || ''}" alt="${novel.title || ''}" class="cover-img" />
        <h3>${novel.title || '-'}</h3>
        <p><strong>Status:</strong> ${novel.status || '-'}</p>
        <p><strong>Tahun:</strong> ${novel.year || '-'}</p>
        <p><strong>Genre:</strong> ${[novel.genre1, novel.genre2, novel.genre3].filter(Boolean).join(', ') || '-'}</p>
        <p><strong>Rating:</strong> ${novel.rating || '-'}</p>
        <p><strong>Total Views:</strong> ${totalViews}</p>
        </div>
      `;
      resultsContainer.appendChild(item);
    });

  } catch (error) {
    console.error('loadGenre error:', error);
    resultsContainer.innerHTML = '<p>Terjadi kesalahan saat mengambil data genre.</p>';
  }
}

// Carousel: muat data dan render slide
async function loadCarousel() {
  track = document.getElementById('carouselTrack');
  if (!track) return;

  try {
    const res = await fetch(RAW_DATA_URL);
    if (!res.ok) throw new Error("Gagal ambil data");
    const data = await res.json();

    track.innerHTML = '';
    data.forEach(item => {
      const slide = document.createElement('div');
      slide.className = 'slide';
      slide.innerHTML = `
      <div onclick="location.href='desk.html?id=${item.id}'">
        <img src="${item.img || ''}" alt="${item.title || ''}">
        <div class="slide-info">
          <span class="status">${item.status || ''}</span>
          <h3>${item.title || ''}</h3>
          <p>${item.desc || ''}</p>
          <div class="tags">
            <span class="rating">${item.rating || ''}</span>
            <span class="views">${item.views || ''}</span>
            ${(item.genres || []).map(g => `<span class="genre">${g}</span>`).join('')}
          </div>
        </div>
        </div>
      `;
      track.appendChild(slide);
    });

    slides = Array.from(track.querySelectorAll('.slide'));
    index = 0;
    update(false);
    attachCarouselEvents();
    startAutoSlide();

  } catch (err) {
    console.error('loadCarousel error:', err);
    if (track) track.innerHTML = '<p>Gagal memuat data carousel.</p>';
  }
}

function update(smooth = true) {
  if (!track || slides.length === 0) return;
  const slideEl = slides[0];
  const w = slideEl.offsetWidth + 20;
  const parent = track.parentElement;
  const o = parent ? (parent.offsetWidth - slideEl.offsetWidth) / 2 : 0;
  currentTranslate = -(index * w) + o;
  track.style.transition = smooth ? "transform .35s ease" : "none";
  track.style.transform = `translateX(${currentTranslate}px)`;
  prevTranslate = currentTranslate;
  updateClasses();
}

function updateClasses() {
  slides.forEach((s, i) => {
    s.classList.remove('active', 'adjacent', 'far');
    if (i === index) s.classList.add('active');
    else if (Math.abs(i - index) === 1) s.classList.add('adjacent');
    else s.classList.add('far');
  });
}

function attachCarouselEvents() {
  if (!track) return;

  // pointerdown pada track
  track.addEventListener('pointerdown', e => {
    startX = e.clientX;
    dragging = true;
    track.style.transition = "none";
    track.setPointerCapture(e.pointerId);
  });

  // pointermove pada window
  window.addEventListener('pointermove', e => {
    if (!dragging || !track) return;
    const d = e.clientX - startX;
    currentTranslate = prevTranslate + d;
    track.style.transform = `translateX(${currentTranslate}px)`;
  });

  // pointerup pada window
  window.addEventListener('pointerup', e => {
    if (!dragging || !track) return;
    dragging = false;
    const d = e.clientX - startX;
    const w = slides[0] ? slides[0].offsetWidth + 20 : 1;
    if (d < -w / 4) index = (index + 1) % slides.length;
    else if (d > w / 4) index = (index - 1 + slides.length) % slides.length;
    update(true);
  });

  // resize -> recalc posisi
  window.addEventListener('resize', () => update(false));
}

function startAutoSlide() {
  stopAutoSlide();
  autoSlideInterval = setInterval(() => {
    if (slides.length === 0) return;
    index = (index + 1) % slides.length;
    update(true);
  }, 3000);
}

function stopAutoSlide() {
  if (autoSlideInterval) {
    clearInterval(autoSlideInterval);
    autoSlideInterval = null;
  }
}

// Inisialisasi saat DOM siap
document.addEventListener('DOMContentLoaded', async () => {
  // Ambil elemen yang bergantung pada DOM
  const resultsContainer = document.getElementById('searchResults');
  const searchInput = document.getElementById('searchInput');
  const genreDropdown = document.getElementById('genreDropdown');

  // Muat data awal dan setup fitur
  await loadNovelData();
  setupRealtimeSearch(searchInput, resultsContainer);
  await loadGenres(genreDropdown);

  // Jika ingin tombol search manual, pastikan ada elemen tombol dan pasang event:
  const searchBtn = document.getElementById('searchBtn');
  if (searchBtn) {
    searchBtn.addEventListener('click', () => searchNovel(searchInput, resultsContainer));
  }

  // Muat carousel
  await loadCarousel();
});
