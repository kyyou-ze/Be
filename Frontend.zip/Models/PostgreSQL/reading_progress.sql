-- Models/PostgreSQL/reading_progress.sql
CREATE TABLE reading_progress (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    novel_id VARCHAR(24) NOT NULL, -- MongoDB ObjectId disimpan sebagai string
    chapter_id VARCHAR(24) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, novel_id)
);
